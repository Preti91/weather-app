const apiKey = '20da423906ccf27bec8c2d81c8f4a2eb';
const weadata=document.querySelector(".weat-data");
const cityname=document.querySelector("#city-name");
const frnam=document.querySelector("form");
const imgicon=document.querySelector(".icon");
frnam.addEventListener("submit",(e)=>{
/*console.log(cityname.value);*/
e.preventDefault();
const cityval=cityname.value;
getweatdata(cityval);
});
async function getweatdata(cityval){
    try{
         const res= await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${cityval}&appid=${apiKey}&units=metric`);
    if(!res.ok){
        throw new Error("network response is not ok");
    }
    const data=await res.json();
    console.log(data);
   const temper= Math.floor(data.main.temp);
   const desce=data.weather[0].description;
   const ico=data.weather[0].icon;
   const details=[
    `FEELS LIKE:${Math.floor(data.main.feels_like )}°C`,
    `HUMIDITY: ${data.main.humidity}%`,
    `WIND SPEED:${data.wind.speed}M/S`
   ];
   weadata.querySelector(".tem").textContent=`${temper}°C`;
   weadata.querySelector(".desc").textContent=`${desce}`;
   imgicon.innerHTML=`<img src="https://openweathermap.org/img/wn/${ico}.png" alt="">`;
   weadata.querySelector(".detail").innerHTML=details.map((deta)=>{
     return `<div>${deta}</div>`
   }).join("");
}

catch(err){
    console.error("Fetch error:", err);
    weadata.querySelector(".tem").textContent="";
    imgicon.innerHTML="";
    weadata.querySelector(".desc").textContent="SOORYY!!!!AN ERROR OCCURED "


}
}
   